from flask import Flask, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv
import re
import requests
import os

# ==========================================
# LOAD ENVIRONMENT VARIABLES
# ==========================================

load_dotenv()

app = Flask(__name__)
CORS(app)


# ==========================================
# IBM CONFIGURATION
# ==========================================

IBM_API_KEY = os.getenv("IBM_API_KEY")
IBM_PROJECT_ID = os.getenv("IBM_PROJECT_ID")

# Mumbai watsonx.ai endpoint
IBM_URL = "https://ap-south-1.aws.wxai.ibm.com"

# Keep this as the model available in your watsonx project
MODEL_ID = "ibm/granite-3-3-8b-instruct"


# ==========================================
# CHECK CONFIGURATION
# ==========================================

print("")
print("====================================")
print("       MEDISCAN IBM BACKEND")
print("====================================")

if IBM_API_KEY:
    print("IBM_API_KEY: FOUND")
else:
    print("IBM_API_KEY: NOT FOUND")

if IBM_PROJECT_ID:
    print("IBM_PROJECT_ID: FOUND")
else:
    print("IBM_PROJECT_ID: NOT FOUND")

print("IBM URL:", IBM_URL)
print("====================================")
print("")


# ==========================================
# GET IBM IAM TOKEN
# ==========================================

def get_iam_token():

    if not IBM_API_KEY:
        raise Exception(
            "IBM_API_KEY is missing from the .env file."
        )

    url = "https://iam.cloud.ibm.com/identity/token"

    headers = {
        "Content-Type":
            "application/x-www-form-urlencoded",
        "Accept":
            "application/json"
    }

    data = {
        "grant_type":
            "urn:ibm:params:oauth:grant-type:apikey",

        "apikey":
            IBM_API_KEY.strip()
    }

    response = requests.post(
        url,
        headers=headers,
        data=data,
        timeout=30
    )

    if response.status_code != 200:

        raise Exception(
            "IBM IAM authentication failed: "
            f"{response.status_code} - "
            f"{response.text}"
        )

    result = response.json()

    token = result.get("access_token")

    if not token:

        raise Exception(
            "IBM IAM did not return an access token."
        )

    print("✅ IBM IAM token generated successfully.")

    return token


# ==========================================
# CALL WATSONX
# ==========================================

def ask_ibm(prompt):

    token = get_iam_token()

    url = (
        f"{IBM_URL}"
        "/ml/v1/text/generation"
    )

    headers = {
        "Authorization":
            f"Bearer {token}",

        "Content-Type":
            "application/json",

        "Accept":
            "application/json"
    }

    params = {
        "version": "2023-05-29"
    }

    body = {

        "model_id":
            MODEL_ID,

        "input":
            prompt,

        "project_id":
            IBM_PROJECT_ID,

        "parameters": {

            "decoding_method":
                "greedy",

            "max_new_tokens":
                400,

            "min_new_tokens":
                20,

            "repetition_penalty":
                1.05
        }
    }

    print("")
    print("Sending request to IBM watsonx...")
    print("Model:", MODEL_ID)

    response = requests.post(
        url,
        headers=headers,
        params=params,
        json=body,
        timeout=90
    )

    print(
        "IBM response status:",
        response.status_code
    )

    if response.status_code != 200:

        raise Exception(
            "IBM AI request failed: "
            f"{response.status_code} - "
            f"{response.text}"
        )

    result = response.json()

    results = result.get("results", [])

    if not results:

        raise Exception(
            "IBM returned no generated response."
        )

    return results[0].get(
        "generated_text",
        ""
    ).strip()


# ==========================================
# HOME
# ==========================================

@app.route("/", methods=["GET"])
def home():

    return jsonify({

        "success": True,

        "message":
            "MediScan IBM AI Backend is running!"

    })


# ==========================================
# SAFETY: EMERGENCY GUARD (runs BEFORE the AI)
# Mirrors the red-flag rules in frontend/remedies.js
# ==========================================

EMERGENCY_PATTERNS = [
    r"chest\s*(pain|pressure|tightness|heaviness)|pain in (my )?chest|heart attack|chest (is )?(hurting|tight)|सीने में दर्द|छातीत दुखणे|छाती दुखणे",
    r"(can'?t|cannot|unable to|hard to|difficulty|trouble|struggling to) breathe?|shortness of breath|breathless|gasping|choking|blue lips|सांस (लेने )?में (तकलीफ|दिक्कत)|श्वास घेण्यास त्रास",
    r"face (is )?droop|slurred speech|can'?t speak|sudden (weakness|numbness)|one side (of (my )?(body|face) )?(weak|numb)|stroke|sudden (loss of vision|confusion)",
    r"(severe|heavy|uncontrol+able|won'?t stop|profuse) bleeding|bleeding (a lot|heavily|won'?t stop)|vomit(ing)? blood|blood in (vomit|stool|urine)|coughing (up )?blood|black (tarry )?stool",
    r"unconscious|not responding|unresponsive|passed out|fainted|seizure|convulsion|fits\b|not waking",
    r"anaphyla|throat (is )?(closing|swelling)|swollen (tongue|lips|throat)|face swelling|swelling of (face|lips|tongue)",
    r"poison|overdose|swallowed (something|pills|chemical|kerosene|phenyl)|ate too many (pills|tablets)|snake ?bite|scorpion|dog bite",
    r"suicid|kill myself|end my life|want to die|self[- ]?harm|hurt myself|मरना चाहता|जीवन संपवा",
    r"head injury|hit (my )?head|fell on (my )?head|concussion",
]

EMERGENCY_REPLY = (
    "This may be an emergency. MediScan does not suggest home remedies for this.\n\n"
    "Please call 112 (emergency) or 108 (ambulance) now, or go to the nearest hospital.\n"
    "If you are having thoughts of self-harm, you can call Tele-MANAS at 14416 (free, 24x7)."
)


def is_emergency(text):
    return any(re.search(p, text, re.I) for p in EMERGENCY_PATTERNS)


def clean_records(records):
    """Accept at most 3 record dicts and cap field sizes (client input is untrusted)."""
    out = []
    for r in records[:3]:
        if not isinstance(r, dict):
            continue
        c = {}
        for k, v in r.items():
            if isinstance(v, list):
                c[k] = [str(x)[:300] for x in v[:12]]
            else:
                c[k] = str(v)[:500]
        out.append(c)
    return out


def format_records(records):
    """Turn retrieved knowledge-base records into prompt text."""
    blocks = []
    for r in records:
        def j(key):
            v = r.get(key) or []
            return "; ".join(v) if isinstance(v, list) else str(v)
        blocks.append(
            f"[{r.get('id','?')}] {r.get('name','')}\n"
            f"Traditional use: {r.get('use','')}\n"
            f"Ingredients: {j('ingredients')}\n"
            f"Preparation: {j('preparation')}\n"
            f"Usage: {r.get('usage','')}\n"
            f"Precautions: {j('precautions')}\n"
            f"Contraindications: {j('contraindications')}\n"
            f"Target population: {r.get('population','')}\n"
            f"See a doctor if: {j('escalation')}\n"
            f"Source: {r.get('source','')}"
        )
    return "\n\n".join(blocks)


# ==========================================
# AI CHAT (grounded in retrieved remedy records)
# ==========================================

@app.route("/chat", methods=["POST"])
def chat():

    try:

        data = request.get_json() or {}

        message = (data.get("message", "") or "").strip()[:500]
        context = data.get("context") or []
        history = data.get("history") or []

        if not message:
            return jsonify({
                "success": False,
                "error": "Please enter a message."
            }), 400

        # Safety check BEFORE the language model is called
        if is_emergency(message):
            return jsonify({"success": True, "response": EMERGENCY_REPLY})

        records = clean_records(context) if isinstance(context, list) else []

        if not records:
            return jsonify({
                "success": True,
                "response": (
                    "I could not find a matching remedy in the MediScan "
                    "knowledge base, so I will not guess. Please try the "
                    "Symptom Search or Knowledge Library, or speak to a "
                    "healthcare professional."
                )
            })

        recent = "\n".join(
            f"{h.get('role','user')}: {str(h.get('content',''))[:300]}"
            for h in history[-4:] if isinstance(h, dict)
        )

        prompt = f"""
You are MediScan, an assistant for a traditional home-remedy knowledge base.

Answer ONLY using the remedy records below. Do not add remedies,
ingredients, quantities or claims that are not in the records.
If the records do not answer the question, say so.

REMEDY RECORDS:
{format_records(records)}

RECENT CONVERSATION:
{recent or "(none)"}

USER QUESTION:
{message}

RULES:
- Describe these as TRADITIONAL uses, not proven medical treatments.
- Always mention precautions or who should avoid the remedy.
- Always mention when to see a doctor (use the record's "See a doctor if").
- Do not diagnose. Do not name medicines or give medicine doses.
- Do not tell anyone to stop prescribed medicines.
- Cite record IDs like [MS-001].
- Plain, short language. Under 180 words.
"""

        answer = ask_ibm(prompt)

        return jsonify({"success": True, "response": answer})

    except Exception as e:

        print("\n❌ CHAT ERROR:")
        print(e)
        print("")

        return jsonify({"success": False, "error": str(e)}), 500


# ==========================================
# RUN SERVER
# ==========================================

if __name__ == "__main__":

    print("")
    print("====================================")
    print("      MEDISCAN IBM AI BACKEND")
    print("====================================")
    print("Server: http://127.0.0.1:5000")
    print("====================================")
    print("")

    app.run(host="127.0.0.1", port=5000, debug=True)
