# MediScan
Run backend: `cd backend && pip install flask flask-cors python-dotenv requests && python server.py`
Open frontend: open `frontend/index.html` (works without backend; AI chat falls back to stored records).
Styles are inside index.html. Edit remedies in `frontend/remedies.js`.
