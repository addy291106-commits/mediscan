/* =========================================================
   MediScan front-end
   Flow (paper Fig. 1):
   User → AI engine → Knowledge base → Safety check → Guidance → Escalation
========================================================= */
"use strict";

const API_BASE = "http://127.0.0.1:5000";
const REMEDIES = window.REMEDIES || [];
const RULES = window.ESCALATION_RULES || [];
const LS_RECENT = "mediscan.recent";
const LS_COMMUNITY = "mediscan.community";

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const lsGet = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* storage unavailable */ } };
const list = (arr, tag = "ul") => arr && arr.length ? `<${tag}>${arr.map((x) => `<li>${esc(x)}</li>`).join("")}</${tag}>` : "<p class='note'>Not recorded.</p>";

/* ---------------- Retrieval (AI-engine stand-in for the MVP) ---------------- */
const STOP = new Set("i am is are the a an and or of to for in on with my me have has had it its this that what how do does can who should when i'm im feel feeling feels got get since from about please help any some very little bit mild minor".split(" "));
const tokens = (t) => (t.toLowerCase().match(/[\p{L}\p{M}\p{N}]+/gu) || []).filter((w) => w.length > 2 && !STOP.has(w));

function retrieve(query, pool = REMEDIES, limit = 6) {
  const q = query.toLowerCase();
  const toks = tokens(q);
  return pool.map((r) => {
    let score = 0; const hits = new Set();
    r.concerns.forEach((c) => { if (q.includes(c.toLowerCase())) { score += 4 + Math.min(c.length / 8, 2); hits.add(c); } });
    const nameText = (r.name + " " + r.local.mr + " " + r.local.hi).toLowerCase();
    const bodyText = (r.use + " " + r.ingredients.join(" ") + " " + r.category).toLowerCase();
    toks.forEach((t) => {
      if (nameText.includes(t)) { score += 3; hits.add(t); }
      else if (r.concerns.some((c) => c.toLowerCase().split(/\s+/).includes(t))) { score += 1.5; hits.add(t); }
      else if (bodyText.includes(t)) { score += 0.75; hits.add(t); }
    });
    return { r, score, hits: [...hits].slice(0, 4) };
  }).filter((x) => x.score >= 2).sort((a, b) => b.score - a.score).slice(0, limit);
}

/* ---------------- Safety check ---------------- */
function checkEscalation(text, { duration = 0, audience = "adult" } = {}) {
  const flags = RULES.filter((rule) => rule.re.test(text)).map((r) => ({ level: r.level, label: r.label, advice: r.advice }));
  if (audience === "infant") flags.push({ level: "doctor", label: "Baby under 1 year", advice: "For babies, please speak to a paediatrician before trying any home remedy. Never give honey to a baby under 1 year." });
  if (duration >= 10) flags.push({ level: "doctor", label: "Symptoms for more than a week", advice: "Lasting symptoms need a proper medical assessment rather than home care." });
  else if (duration >= 5) flags.push({ level: "soft", label: "Symptoms for 4+ days", advice: "If symptoms have lasted more than 3 days or are getting worse, please see a doctor." });
  if (audience === "pregnant") flags.push({ level: "soft", label: "Pregnancy", advice: "Please check any home remedy with your doctor or midwife first. Many herbs are not recommended in pregnancy." });
  const level = flags.some((f) => f.level === "emergency") ? "emergency" : flags.some((f) => f.level === "doctor") ? "doctor" : flags.length ? "soft" : "none";
  return { level, flags };
}

function personalWarnings(r, audience, condition) {
  const out = [];
  const avoid = r.avoidFor || [];
  const audKeys = { infant: ["infant", "child"], child: ["child"], pregnant: ["pregnant"], senior: [], adult: [] }[audience] || [];
  if (audKeys.some((k) => avoid.includes(k))) out.push({ level: "red", text: audience === "pregnant" ? "Not suggested during pregnancy without a doctor's advice." : audience === "infant" ? "Not suitable for babies under 1 year." : "Not suitable for young children." });
  if (condition && avoid.includes(condition)) out.push({ level: "red", text: { anticoagulant: "May interact with blood-thinning medicine. Ask your doctor first.", asthma: "Not recommended with asthma.", gerd: "May worsen acid reflux or ulcers.", "milk-allergy": "Contains milk; avoid with milk allergy or lactose intolerance." }[condition] });
  if (condition === "diabetes" && /honey|jaggery|sugar|tulsi/i.test(r.ingredients.join(" ") + r.precautions.join(" "))) out.push({ level: "amber", text: "Contains sugar or may affect blood sugar. Check with your doctor if on diabetes medicine." });
  if (audience === "senior" && /pepper|ginger|ajwain|clove/i.test(r.ingredients.join(" "))) out.push({ level: "amber", text: "Older adults on regular medicines should check interactions with their doctor." });
  return out;
}

/* ---------------- Cards & modal ---------------- */
function remedyCard(r, opts = {}) {
  const warns = opts.warns || [];
  const blocked = warns.some((w) => w.level === "red");
  const cls = blocked ? "blocked" : warns.length ? "warned" : "";
  const unverified = r.id.startsWith("C-");
  return `<article class="rcard ${cls}">
    <div class="rcard-top">
      <div class="ricon"><i class="fa-solid ${esc(r.icon || "fa-leaf")}"></i></div>
      <div><h3>${esc(r.name)}</h3>
      <div class="local dev">${esc(r.local.mr || "")}${r.local.mr && r.local.hi ? " · " : ""}${esc(r.local.hi || "")}</div></div>
    </div>
    <div class="meta"><span class="badge">${esc(r.category)}</span><span class="badge muted">${esc(r.id)}</span><span class="badge gold">${unverified ? "Community · unverified" : "Traditional use"}</span></div>
    <p class="use">${esc(r.use)}</p>
    ${warns.map((w) => `<div class="rwarn ${w.level === "red" ? "red" : ""}"><i class="fa-solid fa-triangle-exclamation"></i><span>${esc(w.text)}</span></div>`).join("")}
    ${opts.hits && opts.hits.length ? `<div class="match">Matched: ${opts.hits.map(esc).join(", ")}</div>` : ""}
    <div class="esc-mini"><b><i class="fa-solid fa-user-doctor"></i> See a doctor if:</b> ${esc((r.escalation || []).slice(0, 2).join("; "))}${r.escalation && r.escalation.length > 2 ? "…" : ""}</div>
    <div class="rcard-foot"><span class="match">${esc(r.population || "")}</span><button class="btn ghost" data-open="${esc(r.id)}">Full details <i class="fa-solid fa-arrow-right"></i></button></div>
  </article>`;
}

const allRecords = () => [...REMEDIES, ...lsGet(LS_COMMUNITY, [])];

function openModal(id) {
  const r = allRecords().find((x) => x.id === id);
  if (!r) return;
  $("modalBody").innerHTML = `
    <div class="m-head"><div class="ricon"><i class="fa-solid ${esc(r.icon || "fa-leaf")}"></i></div>
      <div><h2 id="modalTitle">${esc(r.name)}</h2><div class="local dev note">${esc(r.local.mr || "")}${r.local.mr && r.local.hi ? " · " : ""}${esc(r.local.hi || "")}</div></div></div>
    <div class="meta"><span class="badge">${esc(r.category)}</span><span class="badge muted">${esc(r.id)}</span><span class="badge ${r.id.startsWith("C-") ? "red" : "gold"}">${esc(r.verification || window.VERIFY_PENDING)}</span></div>

    <div class="m-sec"><h4><i class="fa-solid fa-scroll"></i> Traditional use</h4><div class="m-trad">${esc(r.use)}<p class="note" style="margin:8px 0 0">“Traditionally used” describes custom, not proven medical treatment.</p></div></div>
    <div class="m-sec"><h4><i class="fa-solid fa-basket-shopping"></i> Ingredients</h4>${list(r.ingredients)}</div>
    <div class="m-sec"><h4><i class="fa-solid fa-kitchen-set"></i> Preparation</h4>${list(r.preparation, "ol")}</div>
    <div class="m-sec"><h4><i class="fa-solid fa-clock"></i> Usage information</h4><p>${esc(r.usage || "Not recorded.")}</p></div>

    <div class="m-sec"><h4><i class="fa-solid fa-shield-heart"></i> Safety information</h4>
      <div class="m-safe">
        <h5>Precautions</h5>${list(r.precautions)}
        <h5>Contraindications: who should avoid it</h5>${list(r.contraindications)}
        <h5>Target population</h5><p>${esc(r.population || "Not recorded.")}</p>
      </div></div>

    <div class="m-sec m-esc"><h4><i class="fa-solid fa-user-doctor"></i> Medical escalation: see a doctor if</h4>${list(r.escalation)}</div>

    <div class="m-sec"><h4><i class="fa-solid fa-book"></i> Evidence / source</h4>
      <dl class="m-grid"><div><dt>Source</dt><dd>${esc(r.source)}</dd></div><div><dt>Verification status</dt><dd>${esc(r.verification || window.VERIFY_PENDING)}</dd></div></dl></div>
    <p class="disclaimer">Educational information from a traditional-knowledge archive. Not a diagnosis or prescription. In an emergency call 112.</p>`;
  $("modal").hidden = false;
  document.body.style.overflow = "hidden";
  $("modal").querySelector(".modal-close").focus();
}
function closeModal() { $("modal").hidden = true; document.body.style.overflow = ""; }

/* ---------------- Workflow diagram highlight ---------------- */
function lightFlow(state) {
  const items = [...document.querySelectorAll("#flow li")];
  items.forEach((li) => li.classList.remove("lit", "bad"));
  const upTo = { emergency: [0, 1, 2, 3, 5], full: [0, 1, 2, 3, 4], none: [0, 1, 2] }[state] || [];
  upTo.forEach((i) => items[i] && items[i].classList.add("lit"));
  if (state === "emergency") items[5].classList.add("bad");
}

/* ---------------- Symptom search ---------------- */
function runSearch(query) {
  const audience = $("audience").value;
  const duration = parseInt($("duration").value, 10);
  const condition = $("condition").value;
  const esc_ = checkEscalation(query, { duration, audience });
  const matches = retrieve(query);
  const trace = $("trace"), box = $("escalationBox"), res = $("results");
  const withheld = esc_.level === "emergency";

  const steps = [
    `<span class="step"><i class="fa-solid fa-user"></i> Input received</span>`,
    `<span class="step"><i class="fa-solid fa-microchip"></i> AI engine: ${tokens(query).slice(0, 4).map(esc).join(", ") || "…"}</span>`,
    `<span class="step ${matches.length ? "" : "skip"}"><i class="fa-solid fa-database"></i> Knowledge base: ${matches.length} record${matches.length === 1 ? "" : "s"}</span>`,
    `<span class="step ${esc_.level === "none" ? "" : esc_.level === "emergency" ? "bad" : "warn"}"><i class="fa-solid fa-shield-halved"></i> Safety check: ${esc_.level === "none" ? "no red flags" : esc_.flags.length + " flag" + (esc_.flags.length === 1 ? "" : "s")}</span>`,
    `<span class="step ${withheld ? "bad" : matches.length ? "" : "skip"}"><i class="fa-solid fa-hand-holding-heart"></i> Guidance: ${withheld ? "withheld" : matches.length ? "shown" : "none"}</span>`,
    `<span class="step ${esc_.level === "none" ? "skip" : esc_.level === "emergency" ? "bad" : "warn"}"><i class="fa-solid fa-user-doctor"></i> Escalation: ${esc_.level === "none" ? "not triggered" : esc_.level}</span>`
  ];
  trace.innerHTML = steps.join(""); trace.hidden = false;
  lightFlow(withheld ? "emergency" : matches.length ? "full" : "none");

  /* Escalation banner */
  if (esc_.level === "none") box.innerHTML = "";
  else {
    const cls = esc_.level === "emergency" ? "emergency" : esc_.level === "doctor" ? "doctor" : "soft";
    const title = { emergency: "This may be an emergency. Get medical help now.", doctor: "Please see a doctor", soft: "A few things to keep in mind" }[esc_.level];
    box.innerHTML = `<div class="esc ${cls}" role="alert"><h3><i class="fa-solid ${cls === "emergency" ? "fa-truck-medical" : "fa-user-doctor"}"></i>${title}</h3>
      ${esc_.flags.map((f) => `<p><b>${esc(f.label)}:</b> ${esc(f.advice)}</p>`).join("")}
      ${withheld ? `<p><b>MediScan will not suggest home remedies for this.</b></p><p class="callouts"><a class="btn danger" href="tel:112"><i class="fa-solid fa-phone"></i> Call 112</a><a class="btn danger outline" href="tel:108"><i class="fa-solid fa-ambulance"></i> Ambulance 108</a>${esc_.flags.some((f) => /self-harm/i.test(f.label)) ? `<a class="btn danger outline" href="tel:14416"><i class="fa-solid fa-heart"></i> Tele-MANAS 14416</a>` : ""}</p>` : ""}</div>`;
  }

  /* Guidance */
  if (withheld) { res.innerHTML = ""; }
  else if (!matches.length) {
    res.innerHTML = `<p class="empty">No remedy in the knowledge base matches “${esc(query)}”. Try simpler words (e.g. “cough”, “bloating”), browse the <a href="#library">library</a>, or speak to a healthcare professional.</p>`;
  } else {
    const rows = matches.map((m) => ({ ...m, warns: personalWarnings(m.r, audience, condition) }));
    rows.sort((a, b) => (a.warns.some((w) => w.level === "red") - b.warns.some((w) => w.level === "red")) || b.score - a.score);
    res.innerHTML = `<div class="results-head"><h3>Traditional remedies for “${esc(query)}”</h3><span>${rows.length} matching record${rows.length === 1 ? "" : "s"} · traditional use, not medical treatment</span></div>` +
      rows.map((m) => remedyCard(m.r, { warns: m.warns, hits: m.hits })).join("");
  }
  saveRecent(query);
}

function saveRecent(q) {
  const r = [q, ...lsGet(LS_RECENT, []).filter((x) => x.toLowerCase() !== q.toLowerCase())].slice(0, 6);
  lsSet(LS_RECENT, r); renderRecent();
}
function renderRecent() {
  const r = lsGet(LS_RECENT, []);
  $("recentWrap").hidden = !r.length;
  $("recentList").innerHTML = r.map((q) => `<button type="button" data-q="${esc(q)}">${esc(q)}</button>`).join("");
}

/* ---------------- Library ---------------- */
let activeCat = "All";
function renderLibrary() {
  const q = $("libSearch").value.trim().toLowerCase();
  const rows = REMEDIES.filter((r) => (activeCat === "All" || r.category === activeCat) &&
    (!q || [r.name, r.local.mr, r.local.hi, r.category, r.use, ...r.ingredients, ...r.concerns].join(" ").toLowerCase().includes(q)));
  $("libraryGrid").innerHTML = rows.map((r) => remedyCard(r)).join("");
  $("libEmpty").hidden = rows.length > 0;
}
function renderCategories() {
  const cats = ["All", ...new Set(REMEDIES.map((r) => r.category))];
  $("categoryChips").innerHTML = cats.map((c) => `<button type="button" class="${c === activeCat ? "on" : ""}" data-cat="${esc(c)}">${esc(c)}</button>`).join("");
}
function renderCommunity() {
  const rows = lsGet(LS_COMMUNITY, []);
  $("communityWrap").hidden = !rows.length;
  $("communityGrid").innerHTML = rows.map((r) => remedyCard(r)).join("");
}

/* ---------------- Safety lists ---------------- */
function renderSafety() {
  $("emergencyList").innerHTML = RULES.filter((r) => r.level === "emergency").map((r) => `<li>${esc(r.label)}</li>`).join("");
  $("doctorList").innerHTML = RULES.filter((r) => r.level === "doctor").map((r) => `<li>${esc(r.label)}</li>`).join("") + "<li>Any symptom lasting more than a week</li><li>Symptoms that are getting worse</li>";
}

/* ---------------- AI assistant ---------------- */
const chatHistory = [];
function addMsg(role, html, extra = "") {
  const log = $("chatLog");
  const div = document.createElement("div");
  div.className = `msg ${role}`;
  div.innerHTML = `<div class="bubble ${extra}">${html}</div>`;
  log.appendChild(div); log.scrollTop = log.scrollHeight;
  return div;
}
const sourceChips = (rs) => rs.length ? `<div class="srcs">${rs.map((r) => `<button type="button" data-open="${esc(r.id)}"><i class="fa-solid fa-book"></i> ${esc(r.id)} · ${esc(r.name.split("(")[0].trim())}</button>`).join("")}</div>` : "";

function offlineAnswer(records) {
  if (!records.length) return "I couldn't find a matching remedy in the knowledge base, so I won't guess. Try the Symptom Search or browse the library. If you're worried about your health, please speak to a doctor.";
  const r = records[0];
  return `From the knowledge base: **${r.name}** [${r.id}]\n\nTraditional use: ${r.use}\n\nUsage: ${r.usage}`;
}

/* Safety block (paper Sec. VII): always attached from the stored record, never left to the language model. */
function safetyBlock(records, e) {
  if (!records.length) return "";
  const r = records[0];
  const flags = e.flags.length ? `<div class="rwarn"><i class="fa-solid fa-triangle-exclamation"></i><span>${e.flags.map((f) => `<b>${esc(f.label)}:</b> ${esc(f.advice)}`).join("<br>")}</span></div>` : "";
  return `${flags}<div class="m-safe" style="margin-top:10px;font-size:14px"><h5>Precautions</h5>${list(r.precautions)}<h5>Who should avoid it</h5>${list(r.contraindications)}<h5>See a doctor if</h5>${list(r.escalation)}</div>`;
}

async function askAssistant(message) {
  addMsg("user", esc(message));
  const e = checkEscalation(message);
  if (e.level === "emergency") {
    addMsg("bot", `<b>This may be an emergency.</b>\n${e.flags.map((f) => `• ${esc(f.label)}: ${esc(f.advice)}`).join("\n")}\n\nI won't suggest home remedies for this. Please call <a href="tel:112">112</a> or go to the nearest hospital now.`, "esc-b");
    return;
  }
  const records = retrieve(message, REMEDIES, 3).map((m) => m.r);
  const typing = addMsg("bot", `<span class="typing"><i></i><i></i><i></i></span>`);
  $("chatSend").disabled = true;
  let text, live = false;
  try {
    const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 60000);
    const resp = await fetch(`${API_BASE}/chat`, {
      method: "POST", headers: { "Content-Type": "application/json" }, signal: ctrl.signal,
      body: JSON.stringify({ message, history: chatHistory.slice(-6), context: records.map(({ id, name, use, ingredients, preparation, usage, precautions, contraindications, population, escalation, source }) => ({ id, name, use, ingredients, preparation, usage, precautions, contraindications, population, escalation, source })) })
    });
    clearTimeout(t);
    const data = await resp.json();
    if (!resp.ok || !data.success) throw new Error(data.error || "AI service error");
    text = data.response; live = true;
  } catch (err) {
    text = offlineAnswer(records);
  }
  typing.remove();
  const bold = esc(text).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>");
  addMsg("bot", `${bold}${safetyBlock(records, e)}${sourceChips(records)}<div class="foot">${live ? "Answer grounded in the records above." : "AI service not reachable: showing the stored record directly."} Information only, not medical advice.</div>`);
  chatHistory.push({ role: "user", content: message }, { role: "assistant", content: text });
  $("chatSend").disabled = false; $("chatInput").focus();
}

async function pingBackend() {
  const el = $("kbStatus");
  try {
    const ctrl = new AbortController(); setTimeout(() => ctrl.abort(), 2500);
    const r = await fetch(`${API_BASE}/`, { signal: ctrl.signal });
    if (!r.ok) throw 0;
    el.className = "kb-status on"; el.querySelector("span").textContent = "AI service connected";
  } catch {
    el.className = "kb-status off"; el.querySelector("span").textContent = "AI offline: library & search work";
  }
}

/* ---------------- Preserve form ---------------- */
const lines = (v) => String(v || "").split(/\n+/).map((s) => s.trim()).filter(Boolean);
function submitPreserve(ev) {
  ev.preventDefault();
  const f = new FormData(ev.target), msg = $("preserveMsg");
  const esca = lines(f.get("escalation"));
  if (!esca.length) { msg.className = "form-msg err"; msg.textContent = "Please add at least one condition when a doctor should be seen."; return; }
  const rec = {
    id: "C-" + Date.now().toString(36).toUpperCase(),
    name: f.get("name").trim(), local: { mr: f.get("local").trim(), hi: "" },
    category: "Community", icon: "fa-feather-pointed", concerns: [],
    use: f.get("use").trim(), ingredients: lines(f.get("ingredients")), preparation: lines(f.get("preparation")),
    usage: f.get("usage").trim(), precautions: lines(f.get("precautions")), contraindications: lines(f.get("contra")),
    population: f.get("population").trim(), source: f.get("source").trim(), escalation: esca,
    verification: "Submitted: awaiting expert verification", avoidFor: []
  };
  lsSet(LS_COMMUNITY, [rec, ...lsGet(LS_COMMUNITY, [])]);
  ev.target.reset(); renderCommunity();
  msg.className = "form-msg ok"; msg.textContent = `Saved as ${rec.id}. It appears under “Community submissions” in the library.`;
}

/* ---------------- Init ---------------- */
document.addEventListener("DOMContentLoaded", () => {
  $("statRemedies").textContent = REMEDIES.length;
  $("statCategories").textContent = new Set(REMEDIES.map((r) => r.category)).size;
  $("statEscalation").textContent = RULES.length;
  renderCategories(); renderLibrary(); renderCommunity(); renderSafety(); renderRecent(); pingBackend();

  $("searchForm").addEventListener("submit", (e) => { e.preventDefault(); const q = $("symptomInput").value.trim(); if (q) runSearch(q); });
  document.addEventListener("click", (e) => {
    const open = e.target.closest("[data-open]"); if (open) return openModal(open.dataset.open);
    if (e.target.closest("[data-close]")) return closeModal();
    const q = e.target.closest("[data-q]");
    if (q) { $("symptomInput").value = q.dataset.q; runSearch(q.dataset.q); $("search").scrollIntoView(); }
    const cat = e.target.closest("[data-cat]");
    if (cat) { activeCat = cat.dataset.cat; renderCategories(); renderLibrary(); }
  });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") { closeModal(); $("sidebar").classList.remove("open"); } });
  $("libSearch").addEventListener("input", renderLibrary);
  $("clearRecent").addEventListener("click", () => { lsSet(LS_RECENT, []); renderRecent(); });
  $("chatForm").addEventListener("submit", (e) => { e.preventDefault(); const v = $("chatInput").value.trim(); if (!v) return; $("chatInput").value = ""; askAssistant(v); });
  $("preserveForm").addEventListener("submit", submitPreserve);

  /* nav */
  const menu = $("menuBtn"), side = $("sidebar");
  menu.addEventListener("click", () => { const o = side.classList.toggle("open"); menu.setAttribute("aria-expanded", o); });
  document.querySelectorAll(".nav-link").forEach((a) => a.addEventListener("click", () => side.classList.remove("open")));
  const links = [...document.querySelectorAll(".nav-link")];
  const spy = new IntersectionObserver((entries) => {
    entries.forEach((en) => { if (en.isIntersecting) links.forEach((l) => l.classList.toggle("active", l.getAttribute("href") === "#" + en.target.id)); });
  }, { rootMargin: "-30% 0px -60% 0px" });
  links.forEach((l) => { const s = document.querySelector(l.getAttribute("href")); if (s) spy.observe(s); });
});
